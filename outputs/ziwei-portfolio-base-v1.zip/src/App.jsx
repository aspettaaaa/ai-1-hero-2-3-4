import {
  useEffect,
  useRef,
} from 'react';
import {
  ArrowUpRight,
  Award,
  Bot,
  Boxes,
  Brush,
  Mail,
  MonitorPlay,
  Phone,
  Sparkles,
} from 'lucide-react';
import { contacts, experiences, metrics, profile, projects, strengths } from './data.js';

const navItems = [
  { label: '首页', href: '#hero' },
  { label: '经历', href: '#about' },
  { label: '项目', href: '#projects' },
  { label: '优势', href: '#strengths' },
  { label: '联系', href: '#contact' },
];

const icons = [Brush, Bot, MonitorPlay, Boxes, Sparkles, Award];

function HeroCanvas() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let frameId = 0;
    const particles = Array.from({ length: 90 }, (_, index) => ({
      x: (index * 149) % 1920,
      y: (index * 211) % 1080,
      r: 0.9 + (index % 5) * 0.34,
      s: 0.35 + (index % 7) * 0.05,
    }));

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const draw = (time) => {
      const width = canvas.width;
      const height = canvas.height;
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, '#05070a');
      gradient.addColorStop(0.5, '#081019');
      gradient.addColorStop(1, '#020306');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      ctx.save();
      ctx.globalAlpha = 0.42;
      ctx.strokeStyle = 'rgba(109,245,255,.16)';
      ctx.lineWidth = 1;
      for (let x = -width; x < width * 1.5; x += 74) {
        ctx.beginPath();
        ctx.moveTo(x + Math.sin(time * 0.001) * 20, 0);
        ctx.lineTo(x + 520, height);
        ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(255,255,255,.065)';
      for (let y = 80; y < height; y += 86) {
        ctx.beginPath();
        ctx.moveTo(0, y + Math.cos(time * 0.001 + y) * 8);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
      ctx.restore();

      const pulse = (Math.sin(time * 0.0016) + 1) / 2;
      const radial = ctx.createRadialGradient(width * 0.76, height * 0.36, 20, width * 0.76, height * 0.36, 620);
      radial.addColorStop(0, `rgba(109,245,255,${0.28 + pulse * 0.08})`);
      radial.addColorStop(0.42, 'rgba(109,245,255,.07)');
      radial.addColorStop(1, 'rgba(109,245,255,0)');
      ctx.fillStyle = radial;
      ctx.fillRect(0, 0, width, height);

      ctx.lineCap = 'round';
      for (let i = 0; i < 7; i += 1) {
        const y = height * 0.25 + i * 72 + Math.sin(time * 0.001 + i) * 30;
        const x = width * 0.34 + Math.cos(time * 0.0007 + i) * 180;
        const line = ctx.createLinearGradient(x - 300, y, x + 460, y + 80);
        line.addColorStop(0, 'rgba(109,245,255,0)');
        line.addColorStop(0.5, i % 2 ? 'rgba(214,183,106,.48)' : 'rgba(109,245,255,.58)');
        line.addColorStop(1, 'rgba(109,245,255,0)');
        ctx.strokeStyle = line;
        ctx.lineWidth = 2 + (i % 3);
        ctx.beginPath();
        ctx.moveTo(x - 340, y);
        ctx.bezierCurveTo(x - 80, y - 150, x + 160, y + 180, x + 520, y + 40);
        ctx.stroke();
      }

      particles.forEach((particle) => {
        particle.x += particle.s;
        if (particle.x > 1940) particle.x = -20;
        ctx.fillStyle = 'rgba(226,248,252,.55)';
        ctx.beginPath();
        ctx.arc(
          (particle.x / 1920) * width,
          (particle.y / 1080) * height + Math.sin(time * 0.001 + particle.x) * 10,
          particle.r,
          0,
          Math.PI * 2,
        );
        ctx.fill();
      });

      frameId = window.requestAnimationFrame(draw);
    };

    resize();
    window.addEventListener('resize', resize);
    frameId = window.requestAnimationFrame(draw);

    return () => {
      window.removeEventListener('resize', resize);
      window.cancelAnimationFrame(frameId);
    };
  }, []);

  return <canvas className="hero-canvas" ref={canvasRef} aria-hidden="true" />;
}

function Header() {
  return (
    <header className="site-header">
      <a className="brand" href="#hero" aria-label="返回首页">
        <span className="brand-mark">ZW</span>
        <span>张子薇</span>
      </a>
      <nav aria-label="主导航">
        {navItems.map((item) => (
          <a key={item.href} href={item.href}>
            {item.label}
          </a>
        ))}
      </nav>
      <a className="nav-contact" href={`mailto:${profile.email}`}>
        <Mail size={16} />
        联系我
      </a>
    </header>
  );
}

function Hero() {
  return (
    <section className="hero section-shell" id="hero">
      <video
        className="hero-video"
        poster="/assets/hero-poster.png"
        autoPlay
        muted
        loop
        playsInline
        aria-hidden="true"
      />
      <HeroCanvas />
      <div className="hero-scrim" />
      <div className="hero-content">
        <div className="hero-copy">
          <h1>
            张子薇
            <span>{profile.heroTitle}</span>
          </h1>
          <p>{profile.heroSubtitle}</p>
        </div>
        <div className="hero-actions">
          <a className="primary-button" href="#projects">
            查看作品
            <ArrowUpRight size={18} />
          </a>
          <a className="ghost-button" href={`mailto:${profile.email}`}>
            <Mail size={18} />
            {profile.email}
          </a>
        </div>
      </div>
      <div className="hero-footer">
        <span>Brand Identity</span>
        <span>Visual System</span>
        <span>AI Workflow</span>
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="section-shell about" id="about">
      <div className="section-heading">
        <span>01</span>
        <h2>个人经历</h2>
      </div>
      <div className="about-grid">
        <div className="portrait-panel">
          <img src="/assets/portrait.png" alt="张子薇头像" />
          <div>
            <strong>{profile.role}</strong>
            <span>Brand / IP / Motion / AI</span>
          </div>
        </div>
        <div className="about-main">
          <p className="lead">{profile.intro}</p>
          <div className="contact-strip">
            {contacts.map((item) =>
              item.href ? (
                <a key={item.label} href={item.href}>
                  <span>{item.label}</span>
                  {item.value}
                </a>
              ) : (
                <div key={item.label}>
                  <span>{item.label}</span>
                  {item.value}
                </div>
              ),
            )}
          </div>
          <div className="metric-grid">
            {metrics.map((item) => (
              <div className="metric-card" key={item.label}>
                <strong>{item.value}</strong>
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="timeline">
        {experiences.map((item) => (
          <article className="timeline-item" key={item.company}>
            <div>
              <span>{item.period}</span>
              <h3>{item.company}</h3>
              <p>{item.role}</p>
            </div>
            <ul>
              {item.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  );
}

function Projects() {
  return (
    <section className="section-shell projects" id="projects">
      <div className="section-heading wide-heading">
        <span>02</span>
        <h2>精选项目</h2>
        <p>先用大图卡建立作品集基础节奏，后续可直接替换为你的真实项目截图。</p>
      </div>
      <div className="project-stack">
        {projects.map((project, index) => (
          <article className="project-card" key={project.title}>
            <div className="project-image">
              <img src={project.image} alt={project.title} />
            </div>
            <div className="project-copy">
              <span>{String(index + 1).padStart(2, '0')} / {project.category}</span>
              <h3>{project.title}</h3>
              <p>{project.summary}</p>
              <div className="tag-row">
                {project.stats.map((stat) => (
                  <em key={stat}>{stat}</em>
                ))}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Strengths() {
  return (
    <section className="section-shell strengths" id="strengths">
      <div className="section-heading wide-heading">
        <span>03</span>
        <h2>个人优势</h2>
        <p>把设计能力从工具熟练度推进到策略、协同、技术表达和商业转化。</p>
      </div>
      <div className="strength-grid">
        {strengths.map((item, index) => {
          const Icon = icons[index % icons.length];
          return (
            <article className="strength-card" key={item.title}>
              <Icon size={24} />
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section className="contact-page" id="contact">
      <div className="contact-inner">
        <div>
          <h2>让下一个视觉系统，从一次对话开始。</h2>
          <p>
            欢迎联系我交流品牌升级、视觉系统、IP形象、展会物料、产品内容可视化与AI辅助设计工作流。
          </p>
        </div>
        <div className="contact-actions">
          <a className="primary-button large" href={`mailto:${profile.email}`}>
            <Mail size={20} />
            {profile.email}
          </a>
          <a className="ghost-button large" href={`tel:${profile.phone.replaceAll(' ', '')}`}>
            <Phone size={20} />
            {profile.phone}
          </a>
        </div>
      </div>
    </section>
  );
}

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <About />
        <Projects />
        <Strengths />
        <Contact />
      </main>
    </>
  );
}
