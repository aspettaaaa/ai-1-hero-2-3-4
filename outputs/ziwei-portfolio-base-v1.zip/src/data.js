export const profile = {
  name: '张子薇',
  role: '视觉设计师',
  phone: '136 8128 6470',
  email: 'zhang957852234@qq.com',
  intro:
    '具备从0到1搭建品牌VI体系、IP形象全案与全场景视觉统筹的复合型设计能力。擅长将机器人硬件、技术白皮书、产品宣传等复杂内容转译为清晰、有传播力的视觉语言，并以数据反馈推动设计迭代。',
  heroTitle: '让技术语言拥有更锋利的视觉表达',
  heroSubtitle:
    'Visual designer focused on brand systems, IP identity, exhibition scenarios and AI-assisted creative workflows.',
};

export const metrics = [
  { value: '40+', label: '国内外设计奖项' },
  { value: '99%', label: '品牌辨识度提升' },
  { value: '95%+', label: '创意方案采纳率' },
  { value: '30%', label: 'UI体验提升' },
];

export const contacts = [
  { label: 'Phone', value: profile.phone, href: `tel:${profile.phone.replaceAll(' ', '')}` },
  { label: 'Email', value: profile.email, href: `mailto:${profile.email}` },
  { label: 'Location', value: 'China', href: null },
];

export const experiences = [
  {
    company: '零次方机器人',
    role: '视觉设计师',
    period: '2025.07 - 2026.06',
    points: [
      '独立搭建全触点品牌视觉识别系统与数字资产中台，建立品牌色彩、字体、图形及版式规范。',
      '主导IP形象从概念设定、三视图到动作库、表情系统的完整设计，并延展线上线下互动玩法与实体衍生品。',
      '将机器人硬件与技术逻辑转译为产品宣传册、企业PPT、技术白皮书等大众可理解的视觉内容。',
    ],
  },
  {
    company: '运城职业技术大学',
    role: '辅导员兼艺术设计专任教师',
    period: '2024.08 - 2025.06',
    points: [
      '负责5个班级235名学生的思政教育与日常事务管理，创新AI融合课程设计。',
      '牵头壶口瀑布文旅IP大型设计项目，统筹多部门资源与供应链，实现文创单月300+销量。',
    ],
  },
  {
    company: '北京博乐科技',
    role: '设计实习生',
    period: '2023.01 - 2023.09',
    points: [
      '主导校招品牌全案设计，覆盖主KV、H5、Banner与运营视觉，主视觉点击率80%。',
      '统筹20+雇主品牌项目全流程，线上创意方案拉动日活增长70%。',
    ],
  },
];

export const projects = [
  {
    title: '机器人品牌VI与IP形象系统',
    category: 'Brand System / IP Design',
    image: '/assets/project-robot-brand.png',
    summary:
      '从品牌识别、数字资产中台到IP三视图、动作库、表情系统与场景应用指南，建立统一且可扩展的科技品牌视觉叙事。',
    stats: ['0-1 VI体系', 'IP动作库', '品牌SOP'],
  },
  {
    title: '壶口瀑布文旅IP设计项目',
    category: 'Cultural Tourism / Product Design',
    image: '/assets/project-cultural-ip.png',
    summary:
      '统筹创意提案、产品落地、供应链对接与商业转化，把地域文化符号转化为可销售、可传播的文创产品线。',
    stats: ['300+月销量', '多部门协作', '产品落地'],
  },
  {
    title: '校招雇主品牌全案视觉',
    category: 'Campaign / Operation Design',
    image: '/assets/project-recruitment-campaign.png',
    summary:
      '围绕主KV、H5、Banner与线下场景设计构建统一活动系统，兼顾传播效率、视觉记忆点和品牌转化。',
    stats: ['80%点击率', '1000+传播', '20+项目'],
  },
];

export const strengths = [
  {
    title: '品牌视觉全链路',
    text: '能从策略、VI规范、IP形象、资产中台到组织培训，完成品牌语言的建立与规模化落地。',
  },
  {
    title: '技术内容视觉化',
    text: '将机器人硬件、白皮书、产品逻辑转译为公众易理解的图文、PPT、视频与传播物料。',
  },
  {
    title: '全场景统筹',
    text: '覆盖官网、Banner、社交媒体、展会全案、空间导视与宣传物料，保证多触点一致性。',
  },
  {
    title: 'AI辅助工作流',
    text: '熟悉ComfyUI、Stable Diffusion、LORA微调与Codex脚本自动化，提升视觉资产延展效率。',
  },
  {
    title: '跨维度表达',
    text: '熟练使用Ps、AI、Figma、C4D、Nomad、SketchUp、Procreate与Ae，兼具平面、三维与动态表达。',
  },
  {
    title: '数据驱动迭代',
    text: '以点击率、停留时长、参与人数、销售数据等指标反哺视觉方案，形成商业闭环。',
  },
];
